package com.technoelevate.servlet;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.technoelevate.conn.DbConnect;

import com.technoelevate.dao.UserDAO;
import com.technoelevtae.entity.User;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String cnfpassword = request.getParameter("cnfpassword");
		
//		System.out.println(name+" "+email+" "+password+" "+cnfpassword);
		
	
		if(password.equals(cnfpassword) && name!=null && email!=null)
		{
		User u = new User(name, email, password);

		UserDAO dao = new UserDAO(DbConnect.getConn());
		boolean f = dao.UserRegister(u);
		
		HttpSession session = request.getSession();

		if (f) {
			
			session.setAttribute("sucssMsg", "user Register successfully");
			response.sendRedirect("register.jsp");
			//System.out.println("user Register successfully");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
			response.sendRedirect("register.jsp");
			//System.out.println("something wrong on server");
		}
		}
		else {
			HttpSession session = request.getSession();
			session.setAttribute("errorMsg", "password missmatch");
			response.sendRedirect("register.jsp");
		}
		
	}

}
