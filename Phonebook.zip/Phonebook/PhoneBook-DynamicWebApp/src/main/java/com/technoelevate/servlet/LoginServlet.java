package com.technoelevate.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.technoelevate.conn.DbConnect;
import com.technoelevate.dao.UserDAO;
import com.technoelevtae.entity.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email = req.getParameter("email");
		String password = req.getParameter("password");

		UserDAO dao = new UserDAO(DbConnect.getConn());
		User u = dao.loginUser(email, password);
		HttpSession session = req.getSession();
		if (u != null) {
			session.setAttribute("user", u);
			resp.sendRedirect("index.jsp");
//			System.out.println("User is available= " + u);
		} else {
			session.setAttribute("invalidMsg", "invalid email and password or server error");
			resp.sendRedirect("login.jsp");
//			System.out.println("User is not available= " + u);
		}
	}

}
